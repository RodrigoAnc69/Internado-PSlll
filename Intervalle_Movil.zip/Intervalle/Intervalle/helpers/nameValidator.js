export function nameValidator(name) {
  if (!name) return "Nombre no puede estar vacío."
  return ''
}
