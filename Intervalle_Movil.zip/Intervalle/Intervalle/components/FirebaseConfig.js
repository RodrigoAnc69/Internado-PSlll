// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCfJkTPrl-2Vu0cYLHyfpJki-ENBZbS5eI",
  authDomain: "intervalle-63fd1.firebaseapp.com",
  projectId: "intervalle-63fd1",
  storageBucket: "intervalle-63fd1.appspot.com",
  messagingSenderId: "582684940921",
  appId: "1:582684940921:web:9351150c1c240f981292a8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);