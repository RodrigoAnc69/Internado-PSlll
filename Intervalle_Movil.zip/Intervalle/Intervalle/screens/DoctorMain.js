import React, { useRef, useState, useEffect } from 'react'
import { useRoute } from '@react-navigation/native';
import { TouchableOpacity, StyleSheet, View } from 'react-native'
import { Text } from 'react-native-paper'
import BackgroundDoctor from '../components/Background'
import Logo from '../components/Logo'
import Header from '../components/Header'
import Button from '../components/Button'
import TextInput from '../components/TextInput'
import BackButton from '../components/BackButton'
import { theme } from '../core/theme'
import MapView, { Callout, Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import * as FileSystem from 'expo-file-system';
import { shareAsync } from 'expo-sharing';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import PocketBase from 'pocketbase';
import { Dimensions } from 'react-native';


const pb = new PocketBase('https://intervalle-instance.pockethost.io');

export default function DcotorMain({ navigation }) {
  const route = useRoute();
  const { authData } = route.params || {};
  


  const mapRef = useRef();

  const [hospitals, setHospitals] = useState([]);


  const onRegionChange = (region) => {
    console.log(region);
  };

  const fetchHospitals = async () => {
    try {
      // Primero, obtenemos la lista de estudiantes asignados al usuario autenticado
      const doctorList = await pb.collection('doctors').getList(1, 50, {
        filter: `created >= "2022-01-01 00:00:00" && isActive=true`,
        expand: "hospital, user_assigned",
      });



      // Filtramos los doctores basándonos en el userId del usuario actual
      const filteredDoctors = doctorList.items.filter(doctor => doctor.user_assigned === authData.userId);
      console.log(filteredDoctors);

      let id = "";
      filteredDoctors.forEach(doctor => {
        const doctorId = doctor.id;
        id = doctorId;
        console.log('ID del Doctor:', id);
      });

      // Luego, obtenemos la lista de hospitales filtrando por los doctores obtenidos
      const hospitalList = await pb.collection('hospitals').getList(1, 50, {
        filter: 'created >= "2022-01-01 00:00:00"',
        expand: 'doctor_assigned, students_assigned',
      });

      // Filtramos los hospitales basándonos en los estudiantes asignados
      const filteredHospitals = hospitalList.items.filter(hospital => hospital.doctor_assigned.includes(id));
      console.log(filteredHospitals);

    


      setHospitals(filteredHospitals);

      

      //setHospitals(studentAssignedHospitals);
      // console.log(studentAssignedHospitals);

    } catch (error) {
      console.error('Error fetching hospitals:', error);
    }
  };

  useEffect(() => {
    // Puedes acceder a los datos de autenticación así:
    if (authData) {
      console.log(authData.fullname);
    }
    fetchHospitals();
  }, [authData]);

  const handlePinClick = (pin) => {
    // Lógica para manejar clic en el pin
    console.log('Pin clicado:', pin);
  };

  const sendauthData = () => {
    // Aqui va Lógica para mandar el authdata a la vista de las tareas
    //-------------
    // Navegar a la vista de tareas
    navigation.navigate('TasksDoctor', { authData }); // Pass authData to the 'TasksStudent' screen if needed
  };
  

  const onLogoutPressed = async () => {
    

    const pb = new PocketBase('https://intervalle-instance.pockethost.io');

    try {
      pb.authStore.clear();
      navigation.navigate('LoginScreen')
      console.log(pb.authStore);
    } catch (error) {
      // Handle Log Out error (e.g., display an error message)
      console.error('Log Out error:', error);
    }
  };


  return (
    <BackgroundDoctor>
        <SafeAreaProvider>
            <View>
            <Header>¡Bienvenido, Doctor {authData.fullname}!</Header>
                <MapView
                  provider={PROVIDER_GOOGLE}
                  ref={mapRef}
                  style={styles.map}
                  onRegionChange={onRegionChange}
                  initialRegion={{
                    latitude: -17.3895,
                    latitudeDelta: 0.0922,
                    longitude: -66.1568,
                    longitudeDelta: 0.0421,
                  }}
                  mapType="standard"
                >
                  
                  
                  {hospitals.map((hospital, index) => (
                    <Marker
                      key={index}
                      coordinate={{
                        latitude: hospital.latitude,
                        longitude: hospital.longitude,
                      }}
                      
                      title={hospital.name}
                      {...console.log(`Estudiantes Asignados: ${hospital.expand.students_assigned.map(student => `${student.firstName} ${student.lastName}`).join(', ')}\n`)}
                      description={`Estudiantes Asignados: ${hospital.expand.students_assigned.map(student => `${student.firstName} ${student.lastName}`).join(', ')}\n`}
                
                    >
                      
                      <Callout style={styles.callout}>
                       
                        <Text style={styles.calloutText}>{hospital.name}</Text>
                        <Text style={styles.calloutText}>
                          Estudiantes Asignados: {hospital.expand.students_assigned.map(student => `${student.firstName} ${student.lastName}`).join(', ')}
                        </Text>
                      </Callout>
                    </Marker>
                  ))}

               


                </MapView>
                <StatusBar style="auto" />
                <Button mode="contained" onPress={sendauthData}>
                  Ver Tareas
                </Button>
                  
                <Button mode="contained" onPress={onLogoutPressed}>
                  Cerrar Sesión
                </Button>
            </View>
        </SafeAreaProvider>
      
      
    </BackgroundDoctor>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  map: {
    width: Dimensions.get('window').width * 0.75,
    height: Dimensions.get('window').height * 0.5,
    borderRadius: 10,
    overflow: 'hidden',
  },
  mapOverlay: {
    position: 'absolute',
    bottom: 20,
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderRadius: 10,
    padding: 16,
    width: '70%',
    textAlign: 'center',
    alignSelf: 'center',
  },
  callout: {
    width: 200, // Ajusta el ancho según tus necesidades
    height: 100  
  },
  calloutText: {
    fontSize: 16,
    marginBottom: 5,
  },
})

