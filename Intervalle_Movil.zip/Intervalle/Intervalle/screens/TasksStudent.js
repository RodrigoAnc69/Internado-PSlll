import React, { useRef, useState, useEffect } from 'react'
import { useRoute } from '@react-navigation/native';
import { TouchableOpacity, StyleSheet, View, FlatList } from 'react-native'
import { Text, Button, Dialog, Portal, PaperProvider, } from 'react-native-paper'
import Background from '../components/Background'
import Header from '../components/Header'
import TextInput from '../components/TextInput'
import BackButton from '../components/BackButton'
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import PocketBase from 'pocketbase';
import { Dimensions } from 'react-native';
import * as FileSystem from 'expo-file-system';
import * as DocumentPicker from 'expo-document-picker';


const pb = new PocketBase('https://intervalle-instance.pockethost.io');

  
  
  

export default function TasksStudent({ navigation  }) {
   
    const route = useRoute();
    const { authData } = route.params || {};
    

    const [tasks, setTasks] = useState([]);


    const [visible, setVisible] = React.useState(false);

    const [selectedTask, setSelectedTask] = useState(null);
    const [fileUri, setFileUri] = useState('');

    const [fileName, setFileName] = useState('');

    const [file, setFile] = useState('');

    const showDialog = (task) => {
        setSelectedTask(task);
        setVisible(true);
    };

    const hideDialog = () => {
        setVisible(false);
        setSelectedTask(null);
    };
    
    const uploadFile = async () => {
      try {
        // Utiliza DocumentPicker.getDocumentAsync para seleccionar el archivo
        const result = await DocumentPicker.getDocumentAsync({
          type: '*/*',
          copyToCacheDirectory: false, // Puedes ajustar esto según tus necesidades
        });
        console.log(result);
  
        if (result.canceled === false) {
          // Accede a la URI del archivo seleccionado
          const selectedFileUri = result.assets && result.assets.length > 0 ? result.assets[0].uri : null;
    
          if (selectedFileUri) {
            setFileUri(selectedFileUri);
            setFileName(result.assets[0].name);
            setFile(result.assets[0]);
            console.log(fileName);
            console.log(file);
          } else {
            console.log('No se encontró la URI del archivo en el resultado');
          }
        } else {
          // El usuario canceló la selección de archivos
          console.log('Selección de archivo cancelada');
        }
      } catch (error) {
        console.error('Error seleccionando archivo:', error);
      }
    };
    
    const markAsCompleted = async () => {
        try {
          console.log('Entró en markAsCompleted');
          console.log('fileUri:', fileUri);
      
          if (fileUri) {
            console.log('Adjuntando archivo...');
            const formData = new FormData();
            formData.append('files', {
              uri: file.uri,
              type: file.mimeType,
              name: file.name,
            });
            // Append other fields
            formData.append('id', selectedTask.id);
            formData.append('title', selectedTask.title);
            formData.append('description', selectedTask.description);
            formData.append('completed', true);
            formData.append('student', selectedTask.student);
            formData.append('doctor', selectedTask.doctor);
  
            console.log(formData);
      
            console.log('Enviando solicitud al servidor...');
  
            await pb.collection('tasks').delete(selectedTask.id);
  
            const response = await pb.collection('tasks').create(formData);
      
            console.log('Respuesta del servidor:', response);
      
            if (response) {
              console.log('Archivo subido y tarea actualizada con éxito');
            } else {
              console.error('Error al subir el archivo o actualizar la tarea');
            }
          } else {
            console.log('No hay archivo adjunto, actualizando tarea...');
            const updatedTask = {
              completed: true,
            };
            await pb.collection('tasks').update(selectedTask.id, updatedTask);
          }
      
          hideDialog();
          fetchTasks();
        } catch (error) {
          console.error('Error marking task as completed:', error);
        }
      };
  
   

   
    const fetchTasks = async () => {
      try {
        // Primero, obtenemos la lista de estudiantes asignados al usuario autenticado
        const studentList = await pb.collection('students').getList(1, 50, {
          filter: `created >= "2022-01-01 00:00:00" && isActive=true`,
          expand: "task, user_assigned",
        });



        // Filtramos los estudiantes basándonos en el userId del usuario actual
        const filteredStudents = studentList.items.filter(student => student.user_assigned === authData.userId);
        console.log(filteredStudents);

        let id = "";
        filteredStudents.forEach(student => {
          const studentId = student.id;
          id = studentId;
          console.log('ID del estudiante:', id);
        });

        // Luego, obtenemos la lista de tareas filtrando por los estudiantes obtenidos
        const taskList = await pb.collection('tasks').getList(1, 50, {
          filter: 'created >= "2022-01-01 00:00:00"',
          expand: 'doctor, student',
        });
        // console.log(taskList);

        // Filtramos los tareas basándonos en los estudiantes asignados
        const filteredTasks = taskList.items.filter(task => task.student.includes(id));
        console.log(filteredTasks);

      


        setTasks(filteredTasks);
      } catch (error) {
        console.error('Error fetching tasks:', error);
      }
    };

    useEffect(() => {
      // Puedes acceder a los datos de autenticación así:
      if (authData) {
        console.log(authData.fullname);
      }
      fetchTasks();
    }, [authData]);

    // Filtrar tareas pendientes
    const pendingTasks = tasks.filter((task) => !task.completed);
   
    // Filtrar tareas completadas
    const completedTasks = tasks.filter((task) => task.completed);


  return (
    <Background>
        <BackButton goBack={navigation.goBack} />
        <SafeAreaProvider>
            <View style={styles.container}>
                <Header>Estas son las Tareas asignadas para ti</Header>
                  {/* Tareas Pendientes */}
                  <Text style={styles.sectionTitlePending}>Tareas Pendientes</Text>
                  <FlatList
                      data={pendingTasks}
                      keyExtractor={(item) => item.id.toString()}
                      renderItem={({ item }) => (
                          <View style={styles.taskCard}>
                              <TouchableOpacity onPress={() => showDialog(item)}>
                                  <Text style={styles.taskTitle}>{item.title}</Text>
                                  <Text>{item.description}</Text>
                                  <Text></Text>
                                 
                                  <Text>Asignada Por el Doctor/a: {item.expand.doctor.firstName} {item.expand.doctor.lastName}</Text>
                              </TouchableOpacity>
                          </View>
                      )}
                  />

                  {/* Tareas Completadas */}
                  <Text style={styles.sectionTitleCompleted}>Tareas Completadas</Text>
                  <FlatList
                      data={completedTasks}
                      keyExtractor={(item) => item.id.toString()}
                      renderItem={({ item }) => (
                          <View style={styles.taskCard}>
                              <Text style={[styles.taskTitle, styles.completedTaskTitle]}>{item.title}</Text>
                              <Text>{item.description}</Text>
                              <Text></Text>
                                 
                              <Text>Asignada Por el Doctor/a: {item.expand.doctor.firstName} {item.expand.doctor.lastName}</Text>
                          </View>
                      )}
                  />

                  <Portal>
                      <Dialog visible={visible} onDismiss={hideDialog}>
                          <Dialog.Title>{selectedTask?.title}</Dialog.Title>
                          <Dialog.Content>
                              <Text>{selectedTask?.description}</Text>
                              <Text></Text>
                              <Text>Asignada Por el Doctor/a: {selectedTask?.expand.doctor.firstName} {selectedTask?.expand.doctor.lastName}</Text>
                              <Text></Text>
                              {fileUri ? <Text>Archivo adjunto: {fileName}</Text> : null}
                              <Text></Text>
                              <Button onPress={uploadFile}>Adjuntar Archivo</Button>
                          </Dialog.Content>
                          <Dialog.Actions>
                              <Button theme={{ colors: { primary: 'gray' } }}onPress={hideDialog}>Cancelar</Button>
                              <Button theme={{ colors: { primary: 'green' } }} onPress={markAsCompleted}>Marcar como Completada</Button>
                          </Dialog.Actions>
                      </Dialog>
                  </Portal>


                <StatusBar style="auto" />
            </View>
        </SafeAreaProvider>
      
      
    </Background>
  )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 40, // Ajusta este valor según tus necesidades
      },
      taskCard: {
        backgroundColor: '#FFFFFF',
        borderRadius: 10,
        padding: 16,
        marginBottom: 16,
      },
      taskTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 8,
      },
      sectionTitlePending: {
        fontSize: 20,
        fontWeight: 'bold',
        marginTop: 16,
        marginBottom: 8,
        color: 'red',
        
      },
      sectionTitleCompleted: {
        fontSize: 20,
        fontWeight: 'bold',
        marginTop: 16,
        marginBottom: 8,
        color: 'green',
        
      },
    
      completedTaskTitle: {
        textDecorationLine: 'line-through',
        color: 'gray',
      },  
  //Completa los estilos
});