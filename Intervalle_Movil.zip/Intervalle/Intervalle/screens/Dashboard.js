import React, { useEffect } from 'react'
import Background from '../components/Background'
import Logo from '../components/Logo'
import Header from '../components/Header'
import Paragraph from '../components/Paragraph'
import Button from '../components/Button'


import PocketBase from 'pocketbase';

const url = 'https://intervalle-instance.pockethost.io/'
const client = new PocketBase(url)

export default function Dashboard({ navigation }) {

  useEffect(() => {
    client.collection("Tasks")
    .getFullList()
    .then((res) => console.log(res));
  }, [])

  return (
    <Background>
      <Logo />
      <Header>Accesos Rápidos</Header>
      <Paragraph>
        Los botones de abajo redirigen a partes escenciales del proyecto probando BDD (CRUDS's de usuarios) y AUTH.
      </Paragraph>
      <Button
        mode="outlined"
        onPress={() =>
          navigation.reset({
            index: 0,
            routes: [{ name: 'StartScreen' }],
          })
        }
      >
        Logout
      </Button>

      <Button  
        mode="outlined"
        title="StudentDashboard"
        onPress={() =>
          navigation.reset({
            index: 0,
            routes: [{ name: 'StudentMain' }],
          })
        }
        //onPress={() => navigation.navigate('StudentMain')}
        >
        Student Dashboard
      </Button>

      <Button  
        mode="outlined"
        title="DoctorDashboard"
        onPress={() =>
          navigation.reset({
            index: 0,
            routes: [{ name: 'DoctorMain' }],
          })
        }
        >
        Doctor Dashboard
      </Button>

      
               
          

      
    </Background>
  )
}
