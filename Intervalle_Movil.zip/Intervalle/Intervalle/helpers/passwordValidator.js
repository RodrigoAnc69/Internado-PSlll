export function passwordValidator(password) {
  if (!password) return "Contraseña no puede estar vacío."
  if (password.length < 5) return 'Contraseña debe ser de al menos 5 carácteres.'
  return ''
}
